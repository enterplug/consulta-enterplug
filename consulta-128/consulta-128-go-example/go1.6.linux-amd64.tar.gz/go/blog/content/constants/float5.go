// +build OMIT

package main

import (
	"fmt"
	"math"
)

func main() {
	// START OMIT
	pi := math.Pi
	fmt.Println(pi)
	// STOP OMIT
}
